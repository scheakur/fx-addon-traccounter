module.exports = 'dir/a/index';
